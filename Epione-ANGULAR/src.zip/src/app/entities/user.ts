export class user {
    id : number ;
}